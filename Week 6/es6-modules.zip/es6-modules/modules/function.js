export default function doSomething(){
	alert("Doing something......");
}